<template>
	<view>
		<u-tabbar :list="vuex_tabbar"></u-tabbar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
